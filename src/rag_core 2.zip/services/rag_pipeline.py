from src.services.embedding import get_embedding
from src.db.mongo import collection
from src.services.memory import get_chat_history
import numpy as np


# 🔹 Cosine similarity
def cosine_similarity(a, b):
    try:
        return np.dot(a, b) / (np.linalg.norm(a) * np.linalg.norm(b))
    except:
        return 0.0


# 🔹 Retrieve documents (LIMITED)
def retrieve_documents(query_embedding, top_k=3):
    docs = list(collection.find())
    scored_docs = []

    for doc in docs:
        try:
            if "embedding" not in doc or "text" not in doc:
                continue

            score = cosine_similarity(query_embedding, doc["embedding"])

            scored_docs.append({
                "score": score,
                "text": doc["text"]
            })

        except:
            continue

    scored_docs.sort(key=lambda x: x["score"], reverse=True)
    return scored_docs[:top_k]


# 🔹 Rerank
def rerank_documents(docs, top_n=2):
    return sorted(docs, key=lambda x: x["score"], reverse=True)[:top_n]


# 🔹 Build context (TOKEN SAFE)
def build_context(docs, threshold=0.3):
    filtered = [doc["text"] for doc in docs if doc["score"] > threshold]

    if not filtered:
        return "No relevant context found."

    context = "\n\n---\n\n".join(filtered)

    return context[:1200]  # 🔥 limit tokens


# 🔹 FORMAT MEMORY → structured for LLM
def format_chat_history(history):
    messages = []

    for msg in history:
        try:
            if isinstance(msg, dict):
                role = msg.get("role", "user")
                content = msg.get("content", "")
            else:
                role = "user"
                content = str(msg)

            messages.append({
                "role": role,
                "content": content
            })

        except:
            continue

    return messages


# 🔥 FINAL RAG PIPELINE
def run_rag(query: str, chat_id: str):
    try:
        # 🔹 STEP 1: Get memory (LIMITED)
        history = get_chat_history(chat_id)[-4:]

        # 🔹 STEP 2: Format memory
        history_messages = format_chat_history(history)

        # 🔹 STEP 3: Embedding
        query_embedding = get_embedding(query)

        # 🔹 STEP 4: Retrieve
        docs = retrieve_documents(query_embedding)

        # 🔹 STEP 5: Rerank
        best_docs = rerank_documents(docs)

        # 🔹 STEP 6: Context
        context = build_context(best_docs)

        # 🔹 STEP 7: Prompt (SHORT)
        final_prompt = f"""
Answer the question using context.

Context:
{context}

Question:
{query}

Rules:
- Answer in 2-3 lines
- Use context only
- If not found, say: Not found

Answer:
"""

        return {
            "prompt": final_prompt.strip(),
            "history": history_messages
        }

    except Exception as e:
        return {
            "prompt": f"Error: {str(e)}",
            "history": []
        }
