from src.db.mongo import collection
from datetime import datetime


# 🔹 Save message
def save_message(chat_id, role, content):
    collection.insert_one({
        "chat_id": chat_id,
        "role": role,
        "content": content,
        "timestamp": datetime.utcnow()
    })


# 🔹 Get chat history
def get_chat_history(chat_id, limit=5):
    messages = list(
        collection.find({"chat_id": chat_id})
        .sort("timestamp", -1)
        .limit(limit)
    )

    messages.reverse()

    history = ""
    for msg in messages:
        history += f"{msg['role']}: {msg['content']}\n"

    return history
