from fastapi import UploadFile, HTTPException
import tempfile
import os
import uuid

from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.document_loaders import PyPDFLoader, TextLoader

from src.services.embedding import get_embedding
from src.db.mongo import collection

CHUNK_SIZE = 500
CHUNK_OVERLAP = 100


def extract_text(file_path, filename):
    try:
        if filename.endswith(".pdf"):
            loader = PyPDFLoader(file_path)
        else:
            loader = TextLoader(file_path, encoding="utf-8")

        docs = loader.load()

        # ✅ FIX: empty content handle
        valid_docs = [doc for doc in docs if doc.page_content.strip() != ""]

        if not valid_docs:
            raise Exception("No content extracted")

        return valid_docs

    except Exception as e:
        raise Exception(f"File read error: {str(e)}")


def chunk_docs(docs):
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=CHUNK_SIZE,
        chunk_overlap=CHUNK_OVERLAP
    )

    chunks = []
    for doc in docs:
        texts = splitter.split_text(doc.page_content)
        chunks.extend(texts)

    return chunks


def store_chunks(chunks, filename):
    for chunk in chunks:
        embedding = get_embedding(chunk)

        collection.insert_one({
            "id": str(uuid.uuid4()),
            "text": chunk,
            "embedding": embedding,
            "source": filename
        })


async def process_upload(file: UploadFile):
    try:
        suffix = os.path.splitext(file.filename)[1]

        with tempfile.NamedTemporaryFile(delete=False, suffix=suffix) as tmp:
            content = await file.read()
            tmp.write(content)
            tmp_path = tmp.name

        docs = extract_text(tmp_path, file.filename)
        chunks = chunk_docs(docs)
        store_chunks(chunks, file.filename)

        os.remove(tmp_path)

        return {
            "status": "success",
            "chunks": len(chunks),
            "file": file.filename
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
