# ==============================
# ✅ IMPORTS
# ==============================
import os
from dotenv import load_dotenv
from groq import Groq

from langchain_core.documents import Document
from langchain_community.embeddings import HuggingFaceEmbeddings
from langchain_community.vectorstores import FAISS


# ==============================
# ✅ LOAD ENV
# ==============================
load_dotenv()

api_key = os.getenv("GROQ_API_KEY")

if not api_key:
    raise ValueError("❌ GROQ_API_KEY not found in .env file")

client = Groq(api_key=api_key)


# ==============================
# ✅ LLM FUNCTION (GROQ)
# ==============================
def generate_answer(context, query):
    try:
        response = client.chat.completions.create(
            model="llama3-70b-8192",
            messages=[
                {
                    "role": "user",
                    "content": f"Context:\n{context}\n\nQuestion: {query}"
                }
            ]
        )
        return response.choices[0].message.content

    except Exception as e:
        print("🔥 GROQ ERROR:", e)
        return f"Error: {str(e)}"


# ==============================
# ✅ EMBEDDINGS (FREE)
# ==============================
embeddings = HuggingFaceEmbeddings(
    model_name="all-MiniLM-L6-v2"
)


# ==============================
# ✅ GLOBAL VECTOR STORE
# ==============================
_faiss_vectorstore = None


# ==============================
# ✅ STORE DOCUMENTS (MULTI-DOC)
# ==============================
def store_documents(chunks):
    global _faiss_vectorstore

    if _faiss_vectorstore is None:
        # First time create
        _faiss_vectorstore = FAISS.from_documents(chunks, embeddings)
    else:
        # Add more docs
        _faiss_vectorstore.add_documents(chunks)

    print("✅ Documents added to FAISS")
    return True


# ==============================
# ✅ QUERY DOCUMENTS (FINAL)
# ==============================
def query_documents(query):
    global _faiss_vectorstore

    print("DEBUG vectorstore:", _faiss_vectorstore)

    if _faiss_vectorstore is None:
        return {"answer": "No documents uploaded yet"}

    # 🔥 Improved retrieval
    docs = _faiss_vectorstore.similarity_search(query, k=5)

    print("DEBUG docs:", docs)

    if not docs:
        return {"answer": "No relevant documents found"}

    # 🔥 Context build
    context = "\n\n".join([doc.page_content for doc in docs])

    # 🔥 LLM call
    final_answer = generate_answer(context, query)

    return {"answer": final_answer}
