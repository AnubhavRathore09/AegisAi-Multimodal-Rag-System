from fastapi import APIRouter, UploadFile, File
from pydantic import BaseModel

from src.rag.document_upload import process_upload
from src.services.rag_pipeline import run_rag

from groq import Groq
import os

router = APIRouter()

# ✅ Groq client
client = Groq(api_key=os.getenv("GROQ_API_KEY"))


# =========================
# 📌 Request Schema
# =========================
class ChatRequest(BaseModel):
    query: str
    chat_id: str = "default"


# =========================
# 📌 Upload Route (TXT + PDF)
# =========================
@router.post("/upload")
async def upload_file(file: UploadFile = File(...)):
    """
    Upload TXT or PDF file
    """
    result = await process_upload(file)
    return result


# =========================
# 📌 Chat Route (RAG + LLM)
# =========================
@router.post("/chat")
async def chat(req: ChatRequest):
    try:
        # 🔥 Step 1: Run RAG pipeline
        final_prompt = run_rag(req.query, req.chat_id)

        # ✅ FIX: ensure string
        if not isinstance(final_prompt, str):
            final_prompt = str(final_prompt)

        final_prompt = final_prompt.strip()

        # 🔥 Step 2: Call LLM (Groq)
        response = client.chat.completions.create(
            model="llama-3.1-8b-instant",   # ✅ stable model
            messages=[
                {
                    "role": "user",
                    "content": final_prompt   # ✅ MUST be string
                }
            ],
            temperature=0.7,
        )

        return {
            "response": response.choices[0].message.content,
            "chat_id": req.chat_id
        }

    except Exception as e:
        return {
            "error": str(e),
            "chat_id": req.chat_id
        }


# =========================
# 📌 Health Check (Optional but useful)
# =========================
@router.get("/")
def health_check():
    return {"status": "API running 🚀"}
