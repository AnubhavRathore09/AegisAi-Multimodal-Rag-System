from fastapi import APIRouter, UploadFile, File
from src.services.embedding import get_embedding
from src.db.mongo import collection
from pypdf import PdfReader

router = APIRouter()

def chunk_text(text, chunk_size=300):
    chunks = []
    words = text.split()
    for i in range(0, len(words), chunk_size):
        chunks.append(" ".join(words[i:i+chunk_size]))
    return chunks

@router.post("/upload")
async def upload_pdf(file: UploadFile = File(...)):
    reader = PdfReader(file.file)
    text = ""

    for page in reader.pages:
        text += page.extract_text() or ""

    chunks = chunk_text(text)

    for chunk in chunks:
        embedding = get_embedding(chunk)
        collection.insert_one({
            "text": chunk,
            "embedding": embedding
        })

    return {"message": "PDF processed successfully"}
