from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
import os

# ✅ Load environment variables
load_dotenv()

# ✅ Debug (optional – remove later)
print("GROQ API KEY:", os.getenv("GROQ_API_KEY"))

# ✅ Import routers
from src.api.routes import router

# ✅ Initialize app
app = FastAPI(title="Adaptive RAG API 🚀")

# =========================
# 🔥 CORS (Frontend ke liye important)
# =========================
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# =========================
# 🔥 Include Routes
# =========================
app.include_router(router)

# =========================
# 🔥 Root Endpoint
# =========================
@app.get("/")
def root():
    return {"message": "Adaptive RAG API is running 🚀"}
